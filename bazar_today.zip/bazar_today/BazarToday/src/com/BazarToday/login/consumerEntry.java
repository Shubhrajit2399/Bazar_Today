package com.BazarToday.login;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class consumerEntry
 */
@WebServlet("/consumerEntry")
public class consumerEntry extends HttpServlet {
	
	String url="jdbc:mysql://localhost:3306/bazartoday";
	String username="root";
	String password="shubhra@2399";
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String consumername=request.getParameter("consumer");
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection(url,username,password);
			PreparedStatement st=con.prepareStatement("insert into consumer(consumer_name) values(?)");
			st.setString(1, consumername);
			st.executeUpdate();
			st.close();
			con.close();
			response.sendRedirect("menu.jsp");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
}
