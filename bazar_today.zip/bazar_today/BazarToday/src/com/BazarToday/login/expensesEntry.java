package com.BazarToday.login;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class expensesEntry
 */
@WebServlet("/expensesEntry")
public class expensesEntry extends HttpServlet {
	String url="jdbc:mysql://localhost:3306/bazartoday";
	String username="root";
	String password="shubhra@2399";
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String expensedate=request.getParameter("exdate");
		String consumerid=request.getParameter("consumer");
		String expenseamnt=request.getParameter("expamnt");
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection(url,username,password);
			PreparedStatement st=con.prepareStatement("insert into daily_expense(expense_date,consumer_id,expense_amnt) values(?,?,?)");
			st.setString(1, expensedate);
			st.setString(2, consumerid);
			st.setString(3, expenseamnt);
			st.executeUpdate();
			st.close();
			con.close();
			response.sendRedirect("menu.jsp");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
