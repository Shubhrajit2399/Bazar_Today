package com.BazarToday.login.dao;

import java.sql.*;

public class LoginDao {
	String sql="select * from login where username=? and passwrd=?";
	String url="jdbc:mysql://localhost:3306/bazartoday";
	String username="root";
	String password="shubhra@2399";
	
	public boolean check(String user, String pswd) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection(url,username,password);
			PreparedStatement st=con.prepareStatement(sql);
			st.setString(1,user);
			st.setString(2,pswd);
			ResultSet rs=st.executeQuery();
			if(rs.next()) {
				return true;
			}
			
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		
		return false;
	}
}
