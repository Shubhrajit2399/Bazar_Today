package com.BazarToday.login;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class calculationTable
 */
@WebServlet("/calculationTable")
public class calculationTable extends HttpServlet {
	String url="jdbc:mysql://localhost:3306/bazartoday";
	String username="root";
	String password="shubhra@2399";
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html"); 
		PrintWriter out = response.getWriter(); 
		String fromdate=request.getParameter("date1");
		String todate=request.getParameter("date2");
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection(url,username,password);
			PreparedStatement st1=con.prepareStatement("select credit from credit_ammount where credit_date between ? and ?");
			st1.setString(1, fromdate);
			st1.setString(2, todate);
			ResultSet rs1 = st1.executeQuery();
			out.println("<!DOCTYPE html>");
			out.println("<html>");
			out.println("<head>");
			out.println("<meta charset=\"ISO-8859-1\">");
			out.println("<title>Calculation Table Result</title>");
			out.println("<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">");
			out.println("<link href='https://fonts.googleapis.com/css?family=Archivo Black' rel='stylesheet'>");
			out.println("<link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css\">");
			out.println("<link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css\">");
			out.println("<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js\"></script>");
			out.println("<script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js\"></script>");
			out.println("<style type=\"text/css\">");
			out.println("body{\r\n" + 
					"		margin:5%;\r\n" + 
					"		padding:2%;\r\n" + 
					"		color:white;\r\n" + 
					"		background: #b02999;\r\n" + 
					"		animation: mymove 5s infinite;\r\n" + 
					"	}\r\n" + 
					"	@keyframes mymove {\r\n" + 
					"	  from {background-color: #b02999;}\r\n" + 
					"	  to {background-color: #237f78;}\r\n" + 
					"	}");
			out.println("</style>");
			out.println("</head>");
			out.println("<body>");
			out.println("<center>");
			out.println("<h1 style=\"font-family: 'Archivo Black';\"><u>Calculation Table Result</u></h1>");
			out.println("<h3 style=\"font-family: 'Archivo Black';\"><u>From: "+fromdate+"</u></h3>");
			out.println("<h3 style=\"font-family: 'Archivo Black';\"><u>To: "+todate+"</u></h3>");
			out.println("<div class=\"container\" style=\"text-align: center;font-style: bold; margin-top:5%;\">");
			out.println("<table class=\"table table-bordered\">");
			out.println("<thead>");
			out.println("<tr>");
			out.println("</tr>");
			out.println("</thead>");
			out.println("<tbody>");
			int s1=0;
			out.println("<tr>");
			out.println("<td><h4>Total Credit Amount</h4></td>");
			while (rs1.next()) {
				s1=s1+rs1.getInt(1);
			}	
			out.println("<td><h4>"+s1+"</h4></td>");
			out.println("</tr>");
			PreparedStatement st2=con.prepareStatement("select expense_amnt from daily_expense where expense_date between ? and ?");
			st2.setString(1, fromdate);
			st2.setString(2, todate);
			ResultSet rs2 = st2.executeQuery();
			int s2=0;
			out.println("<tr>");
			out.println("<td><h4>Total Expenses Amount</h4></td>");
			while (rs2.next()) {
				s2=s2+rs2.getInt(1);
			}
			out.println("<td><h4>"+s2+"</h4></td>");
			out.println("</tr>");
			PreparedStatement st3=con.prepareStatement("select meal_count from daily_meals where meal_date between ? and ?");
			st3.setString(1, fromdate);
			st3.setString(2, todate);
			ResultSet rs3 = st3.executeQuery();
			int s3=0;
			out.println("<tr>");
			out.println("<td><h4>Total Number Of Meals</h4></td>");
			while (rs3.next()) {
				s3=s3+rs3.getInt(1);
			}
			out.println("<td><h4>"+s3+"</h4></td>");
			out.println("</tr>");
			out.println("<tr>");
			out.println("<td><h4>Per Meal Charge</h4></td>");
			float s4=(float)s2/(float)s3;
			out.println("<td><h4>"+s4+"</h4></td>");
			out.println("</tr>");
			out.println("</tbody>");
			out.println("</table>");
			
			out.println("<table class=\"table table-bordered\">");
			out.println("<thead>");
			out.println("<tr>");
			out.println("<th><h3><center>Consumer Name</center></h3></th>");
			out.println("<th><h3><center>Total Meal Charge</center></h3></th>");
			out.println("</tr>");
			out.println("</thead>");
			out.println("<tbody>");
			PreparedStatement st5=con.prepareStatement("select sum(daily_meals.meal_count),consumer.consumer_name from daily_meals,consumer where daily_meals.consumer_id=consumer.consumer_id and daily_meals.meal_date between ? and ? group by daily_meals.consumer_id order by daily_meals.consumer_id");
			st5.setString(1, fromdate);
			st5.setString(2, todate);
			ResultSet rs5 = st5.executeQuery();
			ArrayList<Float> ar5 = new ArrayList<Float>();
			while (rs5.next()) {
				out.println("<tr>");
				out.println("<td><h4>"+rs5.getString(2)+"</h4></td>");
				float s5=s4*(float)rs5.getInt(1);
				ar5.add(s5);
				out.println("<td><h4>"+s5+"</h4></td>");
				out.println("</tr>");
				
			}
			out.println("</tbody>");
			out.println("</table>");
			
			out.println("<table class=\"table table-bordered\">");
			out.println("<thead>");
			out.println("<tr>");
			out.println("<th><h3><center>Consumer Name</center></h3></th>");
			out.println("<th><h3><center>Due or Extra</center></h3></th>");
			out.println("</tr>");
			out.println("</thead>");
			out.println("<tbody>");
			PreparedStatement st6=con.prepareStatement("select sum(credit_ammount.credit),consumer.consumer_name from credit_ammount,consumer where credit_ammount.consumer_id=consumer.consumer_id and credit_ammount.credit_date between ? and ? group by credit_ammount.consumer_id order by credit_ammount.consumer_id");
			st6.setString(1, fromdate);
			st6.setString(2, todate);
			int count=0;
			ResultSet rs6 = st6.executeQuery();
			while (rs6.next()) {
				if(ar5.get(count)>=(float)rs6.getInt(1)) {
					out.println("<tr>");
					out.println("<td><h4>"+rs6.getString(2)+"</h4></td>");
					float d6=ar5.get(count)-(float)rs6.getInt(1);
					out.println("<td><h4>"+d6+" [Due]</h4></td>");
					out.println("</tr>");
				}
				else {
					out.println("<tr>");
					out.println("<td><h4>"+rs6.getString(2)+"</h4></td>");
					float d6=(float)rs6.getInt(1)-ar5.get(count);
					out.println("<td><h4>"+d6+" [Extra]</h4></td>");
					out.println("</tr>");
				}
				count++;
			}
			out.println("</tbody>");
			out.println("</table>");
			
			out.println("<a href=\"calculationDate.jsp\"><button type=\"button\" class=\"btn btn-danger\"><h4>Go Back</h4></button></a>");
			out.println("</div>");
			out.println("</center>");
			out.println("</body>");
			out.println("</html>");
		} catch (Exception e) {
			e.printStackTrace();
		}finally { 
			out.close(); 
		} 
	}

}
