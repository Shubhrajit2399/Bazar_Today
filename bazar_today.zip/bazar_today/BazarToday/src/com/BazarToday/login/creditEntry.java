package com.BazarToday.login;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class creditEntry
 */
@WebServlet("/creditEntry")
public class creditEntry extends HttpServlet {
	String url="jdbc:mysql://localhost:3306/bazartoday";
	String username="root";
	String password="shubhra@2399";
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String creditdate=request.getParameter("cdate");
		String consumerid=request.getParameter("consumer");
		String creditamnt=request.getParameter("creditamnt");
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection(url,username,password);
			PreparedStatement st=con.prepareStatement("insert into credit_ammount(credit_date,consumer_id,credit) values(?,?,?)");
			st.setString(1, creditdate);
			st.setString(2, consumerid);
			st.setString(3, creditamnt);
			st.executeUpdate();
			st.close();
			con.close();
			response.sendRedirect("menu.jsp");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
