package com.BazarToday.login;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class expenseTable
 */
@WebServlet("/expenseTable")
public class expenseTable extends HttpServlet {
	String url="jdbc:mysql://localhost:3306/bazartoday";
	String username="root";
	String password="shubhra@2399";
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html"); 
		PrintWriter out = response.getWriter(); 
		String fromdate=request.getParameter("date1");
		String todate=request.getParameter("date2");
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection(url,username,password);
			PreparedStatement st=con.prepareStatement("select expense_date,sum(expense_amnt) from daily_expense where expense_date between ? and ? group by expense_date");
			st.setString(1, fromdate);
			st.setString(2, todate);
			ResultSet rs = st.executeQuery();
			out.println("<!DOCTYPE html>");
			out.println("<html>");
			out.println("<head>");
			out.println("<meta charset=\"ISO-8859-1\">");
			out.println("<title>Daily Expenses Table Result</title>");
			out.println("<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">");
			out.println("<link href='https://fonts.googleapis.com/css?family=Archivo Black' rel='stylesheet'>");
			out.println("<link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css\">");
			out.println("<link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css\">");
			out.println("<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js\"></script>");
			out.println("<script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js\"></script>");
			out.println("<style type=\"text/css\">");
			out.println("body{\r\n" + 
					"		margin:5%;\r\n" + 
					"		padding:2%;\r\n" + 
					"		color:white;\r\n" + 
					"		background: #b02999;\r\n" + 
					"		animation: mymove 5s infinite;\r\n" + 
					"	}\r\n" + 
					"	@keyframes mymove {\r\n" + 
					"	  from {background-color: #b02999;}\r\n" + 
					"	  to {background-color: #237f78;}\r\n" + 
					"	}");
			out.println("</style>");
			out.println("</head>");
			out.println("<body>");
			out.println("<center>");
			out.println("<h1 style=\"font-family: 'Archivo Black';\"><u>Daily Expenses Table Result</u></h1><br>");
			out.println("<div class=\"container\" style=\"text-align: center;font-style: bold; margin-top:5%;\">");
			out.println("<table class=\"table table-bordered\">");
			out.println("<thead>");
			out.println("<tr>");
			out.println("<th><h3><center>Date</center></h3></th>");
			out.println("<th><h3><center>Expense Amount</center></h3></th>");
			out.println("</tr>");
			out.println("</thead>");
			out.println("<tbody>");
			int s=0;
			while (rs.next()) {
				out.println("<tr>");
				out.println("<td><h4>"+rs.getString(1)+"</h4></td>");
				out.println("<td><h4>"+rs.getInt(2)+"</h4></td>");
				s=s+rs.getInt(2);
				out.println("</tr>");
			}
			out.println("</tbody>");
			out.println("</table>");
			out.println("<p><b>Total Expenses Amount: "+s+"</b></p>");
			out.println("<a href=\"expenseTable.jsp\"><button type=\"button\" class=\"btn btn-danger\"><h4>Go Back</h4></button></a>");
			out.println("</div>");
			out.println("</center>");
			out.println("</body>");
			out.println("</html>");
		} catch (Exception e) {
			e.printStackTrace();
		}finally { 
			out.close(); 
		} 
	}

}
